Pasta reservada para modelos, texturas e sons originais do projeto.
Nenhum asset comercial foi copiado do arquivo .3ds enviado.
