/*
 * NEON RUSH - PS3 homebrew starter
 * Original 2.5D speed-platformer prototype.
 * Requires PSL1GHT + Tiny3D installed in the PS3DEV environment.
 *
 * Controls:
 *   D-pad left/right : move
 *   CROSS            : jump
 *   START            : restart after game over
 *   SELECT           : quit
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io/pad.h>
#include <sysutil/sysutil.h>
#include <tiny3d.h>

#define SCREEN_W 1280.0f
#define SCREEN_H 720.0f
#define FLOOR_Y  565.0f
#define PLAYER_W 42.0f
#define PLAYER_H 58.0f
#define MAX_ITEMS 12

typedef struct {
    float x, y, w, h;
    int active;
} Item;

static float player_x = 170.0f;
static float player_y = FLOOR_Y - PLAYER_H;
static float velocity_y = 0.0f;
static float speed = 5.0f;
static int grounded = 1;
static int score = 0;
static int game_over = 0;
static int quit_requested = 0;
static Item items[MAX_ITEMS];
static unsigned int frame_count = 0;

static void sys_callback(uint64_t status, uint64_t param, void *userdata) {
    (void)param; (void)userdata;
    if (status == SYSUTIL_EXIT_GAME) quit_requested = 1;
}

static void reset_game(void) {
    int i;
    player_x = 170.0f;
    player_y = FLOOR_Y - PLAYER_H;
    velocity_y = 0.0f;
    speed = 5.0f;
    grounded = 1;
    score = 0;
    game_over = 0;
    frame_count = 0;
    for (i = 0; i < MAX_ITEMS; ++i) {
        items[i].x = 720.0f + (float)i * 230.0f;
        items[i].y = FLOOR_Y - 105.0f - (float)((i % 3) * 48);
        items[i].w = 25.0f;
        items[i].h = 25.0f;
        items[i].active = 1;
    }
}

static void rect(float x, float y, float w, float h, unsigned int color) {
    tiny3d_SetPolygon(TINY3D_QUADS);
    tiny3d_VertexPos(x, y, 1.0f);
    tiny3d_VertexColor(color);
    tiny3d_VertexPos(x + w, y, 1.0f);
    tiny3d_VertexPos(x + w, y + h, 1.0f);
    tiny3d_VertexPos(x, y + h, 1.0f);
    tiny3d_End();
}

static void draw_scene(void) {
    int i;
    /* Sky and distant layered scenery */
    rect(0, 0, SCREEN_W, SCREEN_H, 0xff17213d);
    rect(0, 390, SCREEN_W, 175, 0xff263b63);
    rect(0, 455, SCREEN_W, 110, 0xff31557a);
    /* Floating platforms / track */
    rect(0, FLOOR_Y, SCREEN_W, 155, 0xff202b38);
    rect(0, FLOOR_Y, SCREEN_W, 12, 0xff34d7c5);
    rect(0, FLOOR_Y + 95, SCREEN_W, 8, 0xff3b5268);

    /* Moving scenery stripes create a sense of speed */
    for (i = 0; i < 10; ++i) {
        float sx = (float)((i * 175) - (frame_count * (unsigned int)(speed * 2.0f)) % 175);
        rect(sx, 625, 75, 5, 0xff536b7d);
    }

    /* Collectibles */
    for (i = 0; i < MAX_ITEMS; ++i) {
        if (items[i].active) {
            rect(items[i].x, items[i].y, items[i].w, items[i].h, 0xffffd34e);
            rect(items[i].x + 7, items[i].y + 5, 11, 15, 0xfffff2a6);
        }
    }

    /* Original player character: abstract teal runner */
    rect(player_x, player_y, PLAYER_W, PLAYER_H, 0xff20d7c4);
    rect(player_x + 7, player_y - 9, 28, 13, 0xff20d7c4);
    rect(player_x + 26, player_y + 12, 8, 8, 0xff101a2b);
    rect(player_x + 5, player_y + PLAYER_H - 5, 16, 8, 0xfff5f7fa);
    rect(player_x + 25, player_y + PLAYER_H - 5, 16, 8, 0xfff5f7fa);

    /* HUD bars: score and speed represented without external fonts */
    rect(30, 28, 260, 18, 0xff0b1425);
    rect(34, 32, (float)((score % 100) * 2 + 4), 10, 0xffffd34e);
    rect(30, 58, 180, 10, 0xff0b1425);
    rect(34, 61, (speed - 4.0f) * 25.0f, 4, 0xff34d7c5);

    if (game_over) {
        rect(350, 260, 580, 150, 0xee080f1c);
        rect(390, 300, 500, 12, 0xffffd34e);
        rect(450, 345, 380, 12, 0xff34d7c5);
    }
}

static void update_game(void) {
    padData pad;
    memset(&pad, 0, sizeof(pad));
    ioPadGetData(0, &pad);

    if (pad.BTN_SELECT) {
        quit_requested = 1;
        return;
    }

    if (game_over) {
        if (pad.BTN_START) reset_game();
        return;
    }

    if (pad.BTN_LEFT && player_x > 35.0f) player_x -= 5.0f;
    if (pad.BTN_RIGHT && player_x < 420.0f) player_x += 5.0f;

    if (pad.BTN_CROSS && grounded) {
        velocity_y = -17.0f;
        grounded = 0;
    }

    velocity_y += 0.72f;
    player_y += velocity_y;
    if (player_y >= FLOOR_Y - PLAYER_H) {
        player_y = FLOOR_Y - PLAYER_H;
        velocity_y = 0.0f;
        grounded = 1;
    }

    speed += 0.0008f;
    for (int i = 0; i < MAX_ITEMS; ++i) {
        if (!items[i].active) continue;
        items[i].x -= speed;
        if (items[i].x < player_x + PLAYER_W &&
            items[i].x + items[i].w > player_x &&
            items[i].y < player_y + PLAYER_H &&
            items[i].y + items[i].h > player_y) {
            items[i].active = 0;
            score += 10;
        }
        if (items[i].x < -40.0f) {
            items[i].x = 1280.0f + (float)(rand() % 500);
            items[i].y = FLOOR_Y - 85.0f - (float)(rand() % 115);
            items[i].active = 1;
        }
    }

    /* Simple obstacle collision */
    if ((frame_count % 260) > 215 && (frame_count % 260) < 222 &&
        player_x < 240.0f && player_y > FLOOR_Y - PLAYER_H - 12.0f) {
        game_over = 1;
    }

    ++frame_count;
}

int main(int argc, char **argv) {
    (void)argc; (void)argv;
    sysUtilRegisterCallback(SYSUTIL_EVENT_SLOT0, sys_callback, NULL);
    ioPadInit(7);
    tiny3d_Init(1024 * 1024);
    reset_game();

    while (!quit_requested) {
        sysUtilCheckCallback();
        update_game();
        tiny3d_Clear(0xff17213d, TINY3D_CLEAR_ALL);
        tiny3d_Project2D();
        draw_scene();
        tiny3d_Flip();
    }

    ioPadEnd();
    return 0;
}
