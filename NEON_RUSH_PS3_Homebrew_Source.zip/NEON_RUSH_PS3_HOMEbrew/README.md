# NEON RUSH — PS3 Homebrew starter

Projeto original de plataforma/velocidade 2.5D para PlayStation 3, preparado como
base de desenvolvimento usando **PSL1GHT + Tiny3D**.

## O que já está no protótipo

- Movimento lateral e pulo pelo controle.
- Cenário em camadas com efeito de deslocamento.
- Itens colecionáveis e pontuação.
- Aumento gradual da velocidade.
- Estado de fim de jogo e reinício.
- Código próprio; não usa arquivos internos, modelos, músicas ou texturas do jogo
  de Nintendo 3DS enviado na conversa.

## Controles

| Controle | Ação |
|---|---|
| Direcional esquerdo/direito | Mover |
| X (Cross) | Pular |
| START | Reiniciar após fim de jogo |
| SELECT | Sair |

## Importante: estado do arquivo

Este ZIP contém **código-fonte inicial**, não um `.PKG` pronto. Não foi possível
compilar ou testar no console nesta sessão, pois a compilação exige o toolchain
PS3DEV/PSL1GHT e a biblioteca Tiny3D instalados em um ambiente de desenvolvimento.

## Compilação

1. Configure o ambiente PSL1GHT e Tiny3D conforme a documentação dos projetos:
   - PSL1GHT: https://github.com/ps3dev/PSL1GHT
   - Tiny3D: https://github.com/wargio/tiny3D
2. Confirme que as variáveis `PS3DEV` e `PSL1GHT` estão configuradas.
3. Abra um terminal no diretório deste projeto.
4. Execute `make`.

O resultado esperado é o executável homebrew produzido pelas regras do SDK.
A geração do pacote instalável depende das regras de pacote presentes na distribuição
do SDK; consulte os exemplos `make pkg` do PSL1GHT instalado.

## Próximas etapas de desenvolvimento

- Trocar os retângulos temporários por modelos 3D originais.
- Adicionar câmera, plataformas suspensas e colisões por fase.
- Criar tela de título, pausa, áudio e salvamento de recordes.
- Ajustar o Makefile à versão exata do SDK instalada.

## Créditos

Conceito e código inicial: NEON RUSH (projeto original criado nesta conversa).
SDK: PSL1GHT. Renderização: Tiny3D.
